

console.log('hello word');
